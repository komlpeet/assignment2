import turtle

def draw_branch(t, branch_length, angle_left, angle_right, reduction_factor, depth):
    """
    Recursively draws a tree pattern using Turtle graphics.

    Parameters:
    - t: Turtle object.
    - branch_length: Length of the current branch.
    - angle_left: Angle for the left branch.
    - angle_right: Angle for the right branch.
    - reduction_factor: Factor by which branch length is reduced in each recursion.
    - depth: Current recursion depth.
    """
    if depth == 0 or branch_length <= 0:
        return

    t.forward(branch_length)

    t.left(angle_left)
    draw_branch(t, branch_length * reduction_factor, angle_left, angle_right, reduction_factor, depth - 1)
    t.right(angle_left)

    # Draw the right branch
    t.right(angle_right)
    draw_branch(t, branch_length * reduction_factor, angle_left, angle_right, reduction_factor, depth - 1)
    t.left(angle_right)
    t.backward(branch_length)

if __name__ == "__main__":
    screen = turtle.Screen()
    screen.bgcolor("white")
    screen.title("Recursive Tree Pattern")

    t = turtle.Turtle()
    t.speed(0)
    t.left(90)
    t.penup()
    t.goto(0, -250)
    t.pendown()

    # User inputs
    branch_length = int(input('Enter the Starting branch length: ')) # 100
    angle_left = int(input('Enter the Left branch angle: ')) #20   
    angle_right = int(input('Enter the Right branch angle: ')) #25 
    reduction_factor = int(input('reduction factor: ')) #0.7 
    depth = int(input('depth: '))  #5

    # Draw the tree
    draw_branch(t, branch_length, angle_left, angle_right, reduction_factor, depth)

    # Finish
    screen.mainloop()