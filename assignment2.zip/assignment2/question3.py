import turtle

def draw_branch(t, branch_length, angle_left, angle_right, reduction_factor, depth):
    """
    Recursively draws a tree pattern using Turtle graphics.

    Parameters:
    - t: Turtle object.
    - branch_length: Length of the current branch.
    - angle_left: Angle for the left branch.
    - angle_right: Angle for the right branch.
    - reduction_factor: Factor by which branch length is reduced in each recursion.
    - depth: Current recursion depth.
    """
    if depth == 0 or branch_length <= 0:
        return

    t.forward(branch_length)

    t.left(angle_left)
    draw_branch(t, branch_length * reduction_factor, angle_left, angle_right, reduction_factor, depth - 1)
    t.right(angle_left)

    # Draw the right branch
    t.right(angle_right)
    draw_branch(t, branch_length * reduction_factor, angle_left, angle_right, reduction_factor, depth - 1)
    t.left(angle_right)
    t.backward(branch_length)

if __name__ == "__main__":
    screen = turtle.Screen()
    screen.bgcolor("white")
    screen.title("Recursive Tree Pattern")

    t = turtle.Turtle()
    t.speed(0)
    t.left(90)
    t.penup()
    t.goto(0, -250)
    t.pendown()

    # User inputs
    branch_length = 100  # Enter the Starting branch length
    angle_left = 20      # Enter the Left branch angle
    angle_right = 25     # Enter the Right branch angle
    reduction_factor = 0.7  # reduction factor
    depth = 5

    # Draw the tree
    draw_branch(t, branch_length, angle_left, angle_right, reduction_factor, depth)

    # Finish
    screen.mainloop()