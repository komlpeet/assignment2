import os
import pandas as pd

# Function to calculate seasonal averages
def calculate_average_temperatures(data_path, output_file):
    seasonal_averages = {}

    for file in os.listdir(data_path):
        if file.endswith(".csv"):
            df = pd.read_csv(os.path.join(data_path, file))
            df['Date'] = pd.to_datetime(df[['Year', 'Month', 'Day']])
            df['Season'] = df['Date'].apply(lambda x: (x.month % 12 + 3) // 3)  # Winter: 1, Spring: 2, etc.

            for season in range(1, 5):
                season_data = df[df['Season'] == season]['Maximum temperature (Degree C)']
                if season not in seasonal_averages:
                    seasonal_averages[season] = []
                seasonal_averages[season].extend(season_data.dropna().tolist())

    with open(output_file, 'w') as f:
        for season, temps in seasonal_averages.items():
            average_temp = sum(temps) / len(temps) if temps else None
            f.write(f"Season {season}: {average_temp:.2f}\n")

# Function to identify station with the largest temperature range
def largest_temperature_range(data_path, output_file):
    largest_range = -float('inf')
    station_with_largest_range = None

    for file in os.listdir(data_path):
        if file.endswith(".csv"):
            df = pd.read_csv(os.path.join(data_path, file))
            station_number = df['Bureau of Meteorology station number'].iloc[0]
            max_temp = df['Maximum temperature (Degree C)'].max()
            min_temp = df['Maximum temperature (Degree C)'].min()
            temp_range = max_temp - min_temp

            if temp_range > largest_range:
                largest_range = temp_range
                station_with_largest_range = station_number

    with open(output_file, 'w') as f:
        f.write(f"Station with largest range: {station_with_largest_range}\n")
        f.write(f"Temperature range: {largest_range:.2f}\n")

# Function to find warmest and coolest stations
def warmest_and_coolest_stations(data_path, output_file):
    max_avg_temp = -float('inf')
    min_avg_temp = float('inf')
    warmest_station = None
    coolest_station = None

    for file in os.listdir(data_path):
        if file.endswith(".csv"):
            df = pd.read_csv(os.path.join(data_path, file))
            station_number = df['Bureau of Meteorology station number'].iloc[0]
            avg_temp = df['Maximum temperature (Degree C)'].mean()

            if avg_temp > max_avg_temp:
                max_avg_temp = avg_temp
                warmest_station = station_number

            if avg_temp < min_avg_temp:
                min_avg_temp = avg_temp
                coolest_station = station_number

    with open(output_file, 'w') as f:
        f.write(f"Warmest station: {warmest_station}, Average temperature: {max_avg_temp:.2f}\n")
        f.write(f"Coolest station: {coolest_station}, Average temperature: {min_avg_temp:.2f}\n")

# Example usage
if __name__ == "__main__":
    import kagglehub
    path = kagglehub.dataset_download("alcheng10/bom-weather-observation-data-select-stations")

    # Calculate average temperatures for each season
    calculate_average_temperatures(path, "average_temp.txt")

    # Identify the station with the largest temperature range
    largest_temperature_range(path, "largest_temp_range_station.txt")

    # Find the warmest and coolest stations
    warmest_and_coolest_stations(path, "warmest_and_coolest_station.txt")