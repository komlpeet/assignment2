import os

def encrypt_text(file_path, encrypted_file_path, n, m):
    """
    Encrypts the text from `file_path` based on the rules provided and writes the encrypted text to `encrypted_file_path`.
    Stores whether each character belongs to the first or second half of the alphabet for decryption.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError("The input file does not exist.")

    with open(file_path, 'r') as file:
        raw_text = file.read()

    encrypted_text = []
    char_metadata = []  # Track which category each character belongs to

    for char in raw_text:
        if char.islower():
            if 'a' <= char <= 'm':
                encrypted_text.append(chr((ord(char) - ord('a') + n * m) % 26 + ord('a')))
                char_metadata.append('first_half_lower')
            elif 'n' <= char <= 'z':
                encrypted_text.append(chr((ord(char) - ord('a') - (n + m) + 26) % 26 + ord('a')))
                char_metadata.append('second_half_lower')
            else:
                encrypted_text.append(char)
                char_metadata.append('other')
        elif char.isupper():
            if 'A' <= char <= 'M':
                encrypted_text.append(chr((ord(char) - ord('A') - n + 26) % 26 + ord('A')))
                char_metadata.append('first_half_upper')
            elif 'N' <= char <= 'Z':
                encrypted_text.append(chr((ord(char) - ord('A') + m ** 2) % 26 + ord('A')))
                char_metadata.append('second_half_upper')
            else:
                encrypted_text.append(char)
                char_metadata.append('other')
        else:
            encrypted_text.append(char)
            char_metadata.append('other')

    with open(encrypted_file_path, 'w') as file:
        file.write(''.join(encrypted_text))

    # Store metadata for decryption
    with open(encrypted_file_path + ".meta", 'w') as meta_file:
        meta_file.write(','.join(char_metadata))

def decrypt_text(encrypted_file_path, decrypted_file_path, n, m):
    """
    Decrypts the text from `encrypted_file_path` based on the rules provided and writes the original text to `decrypted_file_path`.
    Uses metadata to ensure proper decryption logic is applied.
    """
    if not os.path.exists(encrypted_file_path):
        raise FileNotFoundError("The encrypted file does not exist.")

    if not os.path.exists(encrypted_file_path + ".meta"):
        raise FileNotFoundError("The metadata file does not exist.")

    with open(encrypted_file_path, 'r') as file:
        encrypted_text = file.read()

    with open(encrypted_file_path + ".meta", 'r') as meta_file:
        char_metadata = meta_file.read().split(',')

    decrypted_text = []
    for char, meta in zip(encrypted_text, char_metadata):
        if meta == 'first_half_lower':
            decrypted_text.append(chr((ord(char) - ord('a') - n * m + 26) % 26 + ord('a')))
        elif meta == 'second_half_lower':
            decrypted_text.append(chr((ord(char) - ord('a') + n + m + 26) % 26 + ord('a')))
        elif meta == 'first_half_upper':
            decrypted_text.append(chr((ord(char) - ord('A') + n + 26) % 26 + ord('A')))
        elif meta == 'second_half_upper':
            decrypted_text.append(chr((ord(char) - ord('A') - m ** 2 + 26) % 26 + ord('A')))
        else:
            decrypted_text.append(char)

    with open(decrypted_file_path, 'w') as file:
        file.write(''.join(decrypted_text))

def verify_decryption(original_file_path, decrypted_file_path):
    """
    Verifies that the decrypted content matches the original content.
    """
    with open(original_file_path, 'r') as original_file:
        original_content = original_file.read()

    with open(decrypted_file_path, 'r') as decrypted_file:
        decrypted_content = decrypted_file.read()

    return original_content == decrypted_content

# Example Usage
if __name__ == "__main__":
    input_file = "raw_text.txt"
    encrypted_file = "encrypted_text.txt"
    decrypted_file = "decrypted_text.txt"

    # Writing example content to raw_text.txt
    with open(input_file, 'w') as file:
        file.write("The quick brown fox jumps over the lazy dog! Let's meet tomorrow at 7 PM sharp. Bring your notes.")

    # User inputs for n and m
    n = int(input('n: ')) # 3
    m = int(input('m: '))  # 2 

    # Encrypt the file
    encrypt_text(input_file, encrypted_file, n, m)
    print(f"Encrypted content written to {encrypted_file}.")

    # Decrypt the file
    decrypt_text(encrypted_file, decrypted_file, n, m)
    print(f"Decrypted content written to {decrypted_file}.")

    # Verify correctness
    if verify_decryption(input_file, decrypted_file):
        print("Decryption verified successfully.")
    else:
        print("Decryption failed: content does not match.")